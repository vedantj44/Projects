./a.out images/pcp2.png output/vertical_flip.png vflip single
./a.out images/pcp2.png output/blur.png blur single
./a.out images/pcp2.png output/edge.png edge single

